# About this script ------------------------------------------------------------

# This script and data accompanies a workshop at the Netherlands Institute for 
# the Study of Crime and Law Enforcement (NSCR) on using R and litsearchr for 
# identifying search terms for systematic reviews on November 29, 2022.

# The example topic used for the workshop is the effectiveness of de-escalation
# training on reducing police violence. It is not based on a real example, and
# the person who came up with the terms and ran the searches is not an expert
# in this subject matter by any means, so it should not be treated as an actual
# set of search terms, just a mock example to work through the code. 

# With questions about this script, data, or litsearchr in general, please
# contact the author and maintainer, Eliza Grames, at egrames@unr.edu

# For more information about litsearchr, see https://elizagrames.github.io/litsearchr

# Workspace set up -------------------------------------------------------------

# We will be using two packages in this script: litsearchr, and igraph
# igraph is a litsearchr dependency, so does not require separate installation

# litsearchr is not on CRAN, so it must be installed with the remotes package
# If you do not have the remotes package, install it with:
install.packages("remotes")

# If you do not have litsearchr installed, it can be installed with:
remotes::install_github("elizagrames/litsearchr")

# Throughout the script, we use the :: operator to call functions from packages
# Some people prefer to instead load the library at the start of their script,
# e.g. with library(litsearchr), but, we prefer :: since it helps to remember
# which functions are from which packages and avoid the issue of having a script
# that loads ~20 libraries simply because you know it works with those libraries
# loaded but can't remember which one had the functions you're using

# Defining the scope of the question -------------------------------------------

# As with any review, before we begin we need to define the scope of the 
# question. Let's say we want to do a systematic review on the effectiveness of 
# de-escalation training for law enforcement at reducing police violence. 

# We can use the 'PICO' format to define the question as:
# Population: law enforcement officers
# Intervention: de-escalation
# Comparator: officers who have not undergone training
# Outcome: police violence

# Generating the naive search --------------------------------------------------

# The first step with litsearchr is to come up with a 'naive search' which is 
# essentially just the best search string you can come up with in ~5 minutes. 
# For the search, we are going to keep de-escalation and training as two separate
# concepts because we know that articles may say things like 'training in de-escalation'
# or a 'workshop on de-escalation' in addition to more straightforward phrases
# like 'de-escalation training' 

# For this example, we will use the following naive search:

# (("law enforcement" OR "police*" OR "cop" OR "peace officer" OR "sheriff")
# AND ("de-escalation" OR "deescalation" OR "violence prevention*" OR
# "aggression prevention") AND ("training" OR "workshop" OR "instruction" OR
# "class" OR "education") AND ("violence" OR "brutality" OR "misconduct" OR
# "officer-involved shooting" OR "weapon discharge" OR "use of force"))

# We used this search in PsycINFO, ERIC, and Criminal Justice Abstracts on EBSCO

# Naive search results ---------------------------------------------------------

# Load in the results of the naive search
dat.all <- litsearchr::import_results(directory="./de-escalation-refs/")

# Because some articles may be indexed in multiple databases, we want to 
# remove duplicate articles that have the same title so the terms they use
# are not overrepresented in the database
dat <- litsearchr::remove_duplicates(dat.all, field="title", method="exact")

# Comparing the number of rows, it looks like we removed 5 duplicate records
nrow(dat.all)-nrow(dat)

# Extract potential keywords ---------------------------------------------------

# To identify possible keywords, we use a knock-off version of the rapid automatic 
# keyword extraction algorithm (RAKE) which is called 'fakerake' in litsearchr 
# (the logic is the same but it doesn't require java)

all_keywords <-
  litsearchr::extract_terms(
    text = paste(dat$title, dat$abstract, dat$keywords),
    method = "fakerake",
    min_freq = 2,
    ngrams = TRUE,
    min_n = 2,
    language = "English"
  )

# We can look at some of these to get a sense of what they look like with
head(all_keywords, 20)

# Note that all terms are at least two words or longer, which is because in
# the code above, we set ngrams to TRUE to return phrases instead of single words
# and set the min_n (minimum number of words in an n-gram) to 2


# Ignore these lines for now, we will come back to them later with explanation
# terms_ignored <- c("database record", "psycinfo database",
#                    "psycinfo database record", "rights reserved",
#                    "copyright holder", "copyright applies", "email articles",
#                    "express written", "express written permission",
#                    "original published", "original published version",
#                    "published version", "written permission")
# all_keywords <- all_keywords[!all_keywords%in%terms_ignored]

# Create a keyword co-occurrence network ---------------------------------------

# We now create a document-feature matrix (DFM) out of the articles and the keywords
# In the DFM, each row is an article and each column is one of the potential
# keywords identified in the previous step. If a keyword/phrase appears in
# an article, it is a 1 in the DFM, else it is a 0
naivedfm <-
  litsearchr::create_dfm(
    elements = paste(dat$title, dat$abstract, dat$keywords),
    features = all_keywords
  )

# We can use the DFM to create a keyword co-occurrence network because we know
# which terms appear in the same articles together (i.e. co-occur). 
naivegraph <-
  litsearchr::create_network(
    search_dfm = naivedfm,
    min_studies = 2,
    min_occ = 2
  )

# The advantage of using a co-occurrence network for keyword selection is that
# we can use properties of networks to identify the most 'important' terms because
# they will have stronger co-occurrence relationships with other terms that
# are also important, whereas relatively  unimportant terms that occur infrequently
# and not in the right context (i.e. not with other good terms) will have low
# scores for importance in the network

# To see what I mean by that, let's plot the network
# This is a big network with a lot of potential terms, so it may take some time
igraph::plot.igraph(naivegraph, 
                    vertex.label.color = "#00000000", # make labels invisible
                    vertex.label.cex = 0.7, # size of labels
                    vertex.size = sqrt(igraph::strength(naivegraph)), # size of nodes
                    vertex.color = "white", # color of nodes
                    vertex.frame.color = "black", 
                    edge.width = 0.25, 
                    edge.color = "black", 
                    edge.arrow.size = 0.25)

# Select a cutoff and finalize search terms ------------------------------------

# What we want to get out of the network are those big nodes in the center that
# are relatively important based on their node strength, which is a measure 
# of the weighted degrees of a node (i.e. how many connections does it have to
# other nodes, and how well connected are those nodes?)

node.strengths <- sort(igraph::strength(naivegraph), decreasing = T)
head(node.strengths, 50)

# Okay, we have a problem! 'database record' is not a good term. Sometimes,
# this sort of thing happens when you're working with an unfamiliar database.
# An easy fix is that we are going to go back up above where we skipped those
# lines earlier about removing some keywords, and do that now. Is this bad
# coding practice? Sort of, but, it is a training example and we are doing the 
# actual process of removing the terms above, so if we came back to this script 
# fresh, everything would run smoothly.

# Okay, now we are back to where we were before, but the copyright statement
# terms are no longer in the list of potential terms so we can proceed.

# Let's plot the node strengths so we get a sense of the shape of the distribution
# and can see which ones are towards the top
par(pty="s", las=1)
plot(sort(node.strengths), ylab="Node strength", pch=19, cex=0.5, axes=F)
axis(1); axis(2) # add axes
labels <- names(sort(node.strengths)) # pull out labels to add
labels[1:(length(labels)-20)] <- "" # we don't want to add all the labels!
text(sort(node.strengths), labels, pos=4, cex=0.5)

# We can now find a cutoff in node strength above which we will manually consider
# terms to use for the systematic review. We certainly don't want to consider
# all ~2100 terms, but we also don't want to miss some that may be useful in
# finding relevant literature. We want a cutoff that ignores the long tail of
# unimportant keywords but keeps the best ones

# Sometimes using 80/20 is a nice cutoff because of the Pareto principle
cutoff <-
  litsearchr::find_cutoff(
    naivegraph,
    method = "cumulative",
    percent = .20,
    imp_method = "strength"
  )

reducedgraph <-
  litsearchr::reduce_graph(naivegraph, cutoff_strength = cutoff[1])

# This gave us 196 terms to consider using for the search
# If we were cautious about missing terms, we could increase the percent
# in the code above
searchterms <- litsearchr::get_keywords(reducedgraph)

head(searchterms, 20)

# Manually group search terms --------------------------------------------------

write.csv(searchterms, "./search_terms.csv")
# Now we open the file in spreadsheet software (e.g. LibreOffice, Excel)
# And manually group the terms there. It is way easier than doing it in R.

# In your spreadsheet, add a column called 'group' and rename the column with 
# terms 'term'. We want to decide if each term meets any of our PICO groups.
# Some terms may meet multiple groups and can be indicated as both, separated by
# a comma in the 'group' column


# We can read this back in now and pull out each of the elements of PICO
grouped_terms <- read.csv("./search_terms_grouped.csv")

pop <- grouped_terms$term[grep("population", grouped_terms$group)]
int <- grouped_terms$term[grep("intervention", grouped_terms$group)]
comp <- grouped_terms$term[grep("comparator", grouped_terms$group)]
out <- grouped_terms$term[grep("outcome", grouped_terms$group)]

# At this point, we can revisit our naive terms and see if we want to add
# any of them back into our full search (generally recommended)

# (("law enforcement" OR "police*" OR "cop" OR "peace officer" OR "sheriff")
# AND (("de-escalation" OR "deescalation" OR "violence prevention*" OR
# "aggression prevention") AND ("training" OR "workshop" OR "instruction" OR
# "class" OR "education")) AND ("violence" OR "brutality" OR "misconduct" OR
# "officer-involved shooting" OR "weapon discharge" OR "use of force"))

pop <- append(pop, c("law enforcement", "police", "cop", "peace officer", "sheriff"))
int <- append(int, c("de-escalation", "deescalation", "violence prevention", 
                     "aggression prevention"))
comp <- append(comp, c("training", "workshop", "instruction", "class", "education"))
out <- append(out, c("police violence", "police brutality", "officer misconduct",
                     "officer-involved shooting", "weapon discharge", "use of force"))

# Write Boolean search from the terms ------------------------------------------

# First we need to set up a list that contains all our strings of terms
mysearchterms <- list(pop, int, out)

# litsearchr will separate terms within a concept category (i.e. an element of
# PICO) by 'OR' and then link categories with 'AND' so that the search logic is 
# to have at least one term from each category, but in any combination
my_search <-
  litsearchr::write_search(
    groupdata = mysearchterms,
    languages = "English",
    stemming = TRUE,
    closure = "none",
    exactphrase = TRUE,
    writesearch = FALSE,
    verbose = TRUE
  )

# When writing to a plain text file, the extra \ are required to render the 
# * and " properly on some unix-based systems; if copying straight from the 
# console, simply find and replace them in a text editor
my_search

# Checking search against benchmark articles -----------------------------------

# If there has been a previous review on a topic, we may have some idea of what
# articles we expect should be retrieved. Or, we could do some ad-hoc searching
# to find articles that we know are relevant (which was what we did in this case)

# There are probably lots more relevant article, but we will use these three
# as an example of how this process works in litsearchr
gold_standard <-
  c(
    "Evaluation of a police training on de-escalation with trauma-exposed youth",
    "Moving the needle: can training alter officer perceptions and use of de-escalation",
    "Assessing the impact of de-escalation training on police behavior: Reducing police use of force in the Louisville, KY Metro Police Department"
  )

# We have litsearchr write a title-only search out of the benchmark articles
title_search <- litsearchr::write_title_search(titles=gold_standard)
title_search

# We then run that search in a few databases to check if the articles are 
# indexed and we would expect our search to retrieve them (if they aren't in a
# database, it would of course not be reasonable to retrieve them). In this case,
# only articles 1 and 3 are in Criminal Justice Abstracts and none are in
# PsycINFO or ERIC, so we will just check against one database (not recommended
# for real situations!)

# We then run our full search terms in databases we are using for benchmarking
# and export those results, which we can read back in
retrieved_articles <-  litsearchr::import_results(file = "./CJA-fullsearch.ris")

# And then check the results against our benchmark list to see if they were found
articles_found <- litsearchr::check_recall(true_hits = gold_standard,
                                           retrieved = retrieved_articles$title)

# As expected, the second benchmark article was not found because it isn't
# indexed in Criminal Justice Abstracts, but the other two have matches
articles_found